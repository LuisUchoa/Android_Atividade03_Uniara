package com.example.calculadora;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private Button btn_soma;
    private Button btn_sub;
    private Button btn_division;
    private Button btn_multiplicacion;

    private TextView text_resposta;

    private EditText edit_numero_um;
    private EditText edit_numero_dois;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        text_resposta = findViewById(R.id.resposta);

        edit_numero_um = findViewById(R.id.numero1);
        edit_numero_dois = findViewById(R.id.numero2);






        btn_soma = findViewById(R.id.button_soma);
        btn_soma.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                text_resposta.setText( soma( Integer.parseInt(edit_numero_um.getText().toString()),Integer.parseInt(edit_numero_dois.getText().toString()) )+"");
            }
        });


        btn_division = findViewById(R.id.button_division);
        btn_division.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                text_resposta.setText( division( Integer.parseInt(edit_numero_um.getText().toString()),Integer.parseInt(edit_numero_dois.getText().toString()) )+"");

            }
        });

        btn_multiplicacion = findViewById(R.id.button_multiplicacion);
        btn_multiplicacion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                text_resposta.setText( multiplicacion( Integer.parseInt(edit_numero_um.getText().toString()),Integer.parseInt(edit_numero_dois.getText().toString()) )+"");

            }
        });

        btn_sub = findViewById(R.id.button_sub);
        btn_sub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                text_resposta.setText( sub( Integer.parseInt(edit_numero_um.getText().toString()),Integer.parseInt(edit_numero_dois.getText().toString()) )+"");

            }
        });

    }

    public double soma (int a, int b){
        return a+b;
    }

    public double sub (int a, int b){
        return a-b;
    }

    public double multiplicacion (int a, int b){
        return a*b;
    }

    public double division (int a, int b){
        int resposta = 0;

        if (b!=0){
            resposta=a/b;
        }

        return resposta;
    }
}